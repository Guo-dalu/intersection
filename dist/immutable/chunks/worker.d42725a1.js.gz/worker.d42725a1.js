function r(){return new Worker(""+new URL("../workers/worker-24faa4a4.js",import.meta.url).href)}export{r as default};

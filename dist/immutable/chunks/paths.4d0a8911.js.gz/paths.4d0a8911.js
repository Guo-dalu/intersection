var s;const t=((s=globalThis.__sveltekit_1ebw5rz)==null?void 0:s.base)??"/intersection";var e;const a=((e=globalThis.__sveltekit_1ebw5rz)==null?void 0:e.assets)??t;export{a,t as b};

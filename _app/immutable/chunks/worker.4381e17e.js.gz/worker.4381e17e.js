function r(){return new Worker(""+new URL("../workers/worker-b2c419e9.js",import.meta.url).href)}export{r as default};
